SELECT 
    r.RegionName,
    YEAR(s.DateSales) AS Year,
    SUM(s.TotalPrice) AS Total
FROM sales s
INNER JOIN regions r ON s.RegionID = r.RegionID
GROUP BY r.RegionName, YEAR(s.DateSales)
ORDER BY Year ASC, Total DESC;
