-- Approccio 1 LEFT JOIN

SELECT t.ProductName
FROM toys t
LEFT JOIN sales s ON t.ProductID = s.ProductID
WHERE s.SalesID IS NULL;



-- In questo modo se un prodotto non è stato venduto, i campi della tabella sales saranno NULL

-- Approccio 2 NOT IN

SELECT ProductName
FROM toys
WHERE ProductID NOT IN (
    SELECT DISTINCT ProductID
    FROM sales
);

-- Mostra dalla tabella toys solo i prodotti il cui ProductID non è presente nella lista della subquery

