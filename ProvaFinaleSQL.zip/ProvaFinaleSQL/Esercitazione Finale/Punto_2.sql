SELECT 
    t.ProductName,
    YEAR(s.DateSales) AS Year,
    SUM(s.TotalPrice) AS Total
FROM sales s
INNER JOIN toys t ON s.ProductID = t.ProductID
GROUP BY t.ProductName, YEAR(s.DateSales)
ORDER BY Year;

