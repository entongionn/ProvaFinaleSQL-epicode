CREATE TABLE Regions (
    RegionID INT PRIMARY KEY,       
    RegionName VARCHAR(100) NOT NULL 
);

INSERT INTO regions (RegionID, RegionName)
VALUES
    (1, 'North America'),
    (2, 'South America'),
    (3, 'Europe'),
    (4, 'Asia'),
    (5, 'Africa'),
    (6, 'Australia'),
    (7, 'Antarctica'),
    (8, 'Central America'),
    (9, 'Middle East'),
    (10, 'South Asia'),
    (11, 'East Asia'),
    (12, 'Southeast Asia'),
    (13, 'Western Europe'),
    (14, 'Eastern Europe'),
    (15, 'Pacific Islands');
