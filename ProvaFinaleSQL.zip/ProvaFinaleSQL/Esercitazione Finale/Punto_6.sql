SELECT 
    t.ProductName,
    MAX(s.DateSales) AS LastSaleDate
FROM sales s
INNER JOIN toys t ON s.ProductID = t.ProductID
GROUP BY t.ProductName
ORDER BY LastSaleDate DESC;
