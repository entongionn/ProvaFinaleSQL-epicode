SELECT 
    t.Category,
    SUM(s.Quantity) AS BestSelling
FROM sales s
INNER JOIN toys t ON s.ProductID = t.ProductID
GROUP BY t.Category
ORDER BY BestSelling DESC
LIMIT 1;

